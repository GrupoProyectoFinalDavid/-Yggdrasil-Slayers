using System;
using UnityEngine;

namespace Cainos.LucidEditor
{
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Method, AllowMultiple = true)]
    public class HelpBoxIfAttribute : Attribute
    {
        public readonly string condition;
        public readonly string message;
        public readonly HelpBoxMessageType type;

        public HelpBoxIfAttribute(string condition, string message)
        {
            this.condition = condition;
            this.message = message;
            this.type = HelpBoxMessageType.Info;
        }

        public HelpBoxIfAttribute(string condition, string message, HelpBoxMessageType type)
        {
            this.condition = condition;
            this.message = message;
            this.type = type;
        }
    }
}